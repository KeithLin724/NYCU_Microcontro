from math import floor

x = input("Hz : array ")
arr = list(map(int, x.split()))
print("Th0 : , Tl0 : ")
for i in arr:
    a = i
    i *= 4  # mul 4 to hight
    i = (1/i) * 0.5
    i = i/(10**-6)
    i = 65536 - i
    print("db ", floor(i/256), end=',')
    print(floor(i % 256), end=',')
    print(a)
